package com.example.colcom.models;

public class User {
    String id,mail,name;
    public void setUid(String uid) {
        this.id=uid;
    }

    public void setEmail(String email) {
        this.mail=email;
    }

    public String getName() {
        return name;
    }
}
