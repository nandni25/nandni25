package com.example.colcom.models;

public class AllMethods {
    public static String name="";
}
